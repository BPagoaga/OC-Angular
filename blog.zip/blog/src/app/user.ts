export class User {
  name: string;

  constructor(user) {
    this.name = user.name;
  }
}
